<?php
$title = "Home";
$content = '<img src="images/diamond1.png" class="imgLeft"/>
<h3> Welcome </h3>
<p>
    You are in the diamond world! Pick up your favirate diamond from thousands of best diamond providers
    all over the world.
    
    All the diamonds on our platform are well crafted using the state of art technology.
    
    We 100% guanrantee that our diamonds are real, which are accredited independent gemological laboratory. 
 

    <br>
</p>


<img src="images/diamond3.jpg" class="imgRight"/>
    <br>

<h3> Join us today! </h3>
<p>
    Join us today and pick up your best for the wedding and your specials.
    
    Everlasting love with everlasting diamond!
</p>';

$sidePicture = '<img alt="sidebar" title="sidebar" src="images/sidebar.jpg" style="height: 100%; width: 100%; object-fit: contain" />';
include 'Template.php';


?>

