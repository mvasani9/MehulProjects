<?php
    $host = 'localhost';
    $user = 'root';
    $passwd = '';
    $database = 'diamonddb';
   


