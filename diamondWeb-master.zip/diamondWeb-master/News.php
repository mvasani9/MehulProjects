<?php

$title = "News";
$content = '

<img src="images/diamond4.jpg" class="imgRight"/>
    <br>

<h3> New Arraivals </h3>
<p>
    Our new diamond ring Love4Ever just arrived! Designed by Chinese artists Yuanqi Wang. <br/>
    
    Only one in the earth, Go get it!
</p>';

include 'Template.php';
?>
