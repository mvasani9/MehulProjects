<?php
$title = "Management";
$content = '<h3>Welcome</h3>
            <a href="userlogin.php">Login</a><br/>
            <a href="userlogout.php">Logout</a><br/>';
        
include './Template.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

